/* Copyright (c) 2010-2012, The Tor Project, Inc. */
/* See LICENSE for licensing information */

#ifndef _TOR_STATUS_H
#define _TOR_STATUS_H

int log_heartbeat(time_t now);

#endif

